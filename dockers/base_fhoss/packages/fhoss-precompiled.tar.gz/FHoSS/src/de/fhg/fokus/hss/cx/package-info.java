/**
 * \package de.fhg.fokus.hss.cx
 * This package contains the Cx-Interface implementation.
 */
package de.fhg.fokus.hss.cx;