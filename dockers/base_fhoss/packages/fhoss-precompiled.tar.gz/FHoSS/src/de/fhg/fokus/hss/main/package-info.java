/**
 * \package de.fhg.fokus.hss.main
 * This is the main package which start the HSS aplication. Contains the HSSContainer with the main class and also related classes for
 * workers and tasks  
 */
package de.fhg.fokus.hss.main;