/**
 * \package de.fhg.fokus.hss.path
 * Classes for web gui navigation data.
 */
package de.fhg.fokus.hss.path;