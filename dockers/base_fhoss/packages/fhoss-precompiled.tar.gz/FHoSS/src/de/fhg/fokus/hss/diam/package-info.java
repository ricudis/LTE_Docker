/**
 * \package de.fhg.fokus.hss.diam
 * Contains the Diameter Stack, specific diameter constants and util avp manipulation functions (in UtilAVP.java).   
 */
package de.fhg.fokus.hss.diam;