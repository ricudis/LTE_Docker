/**
 * \package de.fhg.fokus.hss.sh
 * This package contains the Sh-Interface implementation.
 */
package de.fhg.fokus.hss.sh;