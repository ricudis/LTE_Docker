/**
 * \package de.fhg.fokus.hss.auth
 * This package contains the Milenage implementation for authentication.
 */
package de.fhg.fokus.hss.auth;