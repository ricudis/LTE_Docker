/**
 * \package de.fhg.fokus.hss.db
 * This package contains all the sub-packages related to database: "model" sub-package with all the tables types and "op" sub-package 
 * with all the coresponding DAO classes. 
 */
package de.fhg.fokus.hss.db;