/**
 * \package de.fhg.fokus.hss.zh
 * This package contains the implementation of the Zh-Interface.
*/

package de.fhg.fokus.hss.zh;